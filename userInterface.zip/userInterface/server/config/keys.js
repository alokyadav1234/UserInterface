module.exports = {
mongouri:"mongodb+srv://useralok:oMozmnyn6JLyEDSJ@firstcluster.atiaw.mongodb.net/userinterface?retryWrites=true&w=majority",
JWT_SECRET:"asdefasdef",
}